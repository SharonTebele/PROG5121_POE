
package chatapp;

import java.util.Objects;
import java.util.regex.Pattern;

public class Login {
    
    // =====Registration Details ====
    private String firstName;
    private String lastName;
    private String username; // must be no more than 5 characters long, should also contain "_"
    private String password; // must be at least 8 characters long, contain a capital letter,contain a number, contain a special character
    private String cellNumber; // must contain the international country code followed by the number with no more than 10 characters long

    // ===== Login result state =====
    private Boolean isAuthenticated = false;
    
    public Login(){}
    
    public Login (String firstName, String lastName, String username, String password, String cellNumber) {
      this.firstName = firstName;
      this.lastName = lastName;
      this.username = username;
      this.password = password;
      this.cellNumber = cellNumber;
    }
//Username must contain an underscore (_) and is no longer than 5 characters long.
    public boolean CheckUserName(String username){
    if (username == null) return false;
    boolean hasUnderscore = username.contains("_");
    boolean lengthOk = username.length() <=5;
    return hasUnderscore && lengthOk;
    }
    // Password muct contain at least 8 characters, a capital letter, a number, and a special character.
    public boolean CheckPassword (String password){
    if (password == null) return false;
    boolean lengthOkk = password.length() >=8;
    boolean capitalLetter = Pattern.compile("[A-Z]").matcher(password).find();
    boolean hasNumber = Pattern.compile("[0-9]").matcher(password).find();
    boolean specialChar = Pattern.compile("[^A-Za-z0-9]").matcher(password).find();
    return lengthOkk && capitalLetter && hasNumber && specialChar;
    }
    
// The Cell phone number must contain the international country code (+...) followed by the number, which is no more than 10 characters long.
// The international country code must start with (+), followed by 1-3 country code, and lastly 1-10 subscriber number.
// Examples: +27838968976 or +277652893458 
    public boolean CheckCellNumber (String cellNumber){
    String regex = "^\\+\\d{1,3}\\d{1,10}$";
    return Pattern.compile(regex).matcher(cellNumber).matches();
    }
    //---------Registration------------
    // returns the exact messages stipulated
    // validate infomation entered by user
    public String registerUser (String firstName, String lastName, String username, String password, String cellNumber){
    if (!CheckUserName(username)){
    return "Username not correctly formatted, please ensure that your username contains an underscore and is no more than five Charecters in length.";
    }
    if (!CheckPassword(password)){
    return "Password not correctly formatted, pleas ensure that the password contains at least eight characters, a capital letter, a number and a special character.";
    }
    if (!CheckCellNumber(cellNumber)){
    return "Cell phone number is incorrectly formatted or does not contain international code";
    }
    
    
    this.firstName = firstName;
    this.lastName = lastName;
    this.username = username;
    this.password = password;
    this.cellNumber = cellNumber;
    // After successful registration, a confirmation message will be returned.
    return "Username successfully captured, Password successfully captured and Cell phone number successfully added.";
    }
    
    public boolean loginUser(String usedUsername, String usedPassword){
    boolean ok = Objects.equals(this.username,usedUsername)
            && Objects.equals(this.password, usedPassword);
    this.isAuthenticated = ok;
    return ok;
    }
    
    public String loginStatusReturn(){
    if (isAuthenticated){
    return "Welcome" + firstName + ", " + lastName + " it is great seeing you again.";
    } else {
        return "Username or Password incorrect, please try again.";
    }
    }
    
    public String getUsername(){return username;}
    public String getPassword(){return password;}
    public String getCellNumber(){return cellNumber;}
/*
    *References
    *AI attributes for regex idea
    *Ghatgpt. (2026,September 18)error checks and guidance on the code conceptualising
    *OpenAI. Prompt: "create regex to validate phone numbers that begins with a country code"
    */    

    /**
     *
     * @param string
     * @return
     */
    public boolean checkCellNumber(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   // public boolean checkCellNumber(String string) {
     //   throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}

    //public boolean checkCellNumber(String string) {
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}

    public boolean checkPassword(String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean checkUsername(String kyl_1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Object returnLoginStatus() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
