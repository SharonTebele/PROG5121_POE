import chatapp.Login;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class LoginTest {

    private static Login login;

    public LoginTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        login = new Login();
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testUsernameCorrectFormat_Message() {
        String msg = login.registerUser("Kyle", "Smith", "Kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(msg.contains("Username Successfully captured."));
        assertTrue(msg.contains("Password Successfully captured."));
        assertTrue(msg.contains("Cell phone number Successfully captured."));
    }

    @Test
    public void testUsernameIncorrectFormat_Message() {
        String msg = login.registerUser("Kyle", "Smith", "Kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Username is not correctly formatted, please ensure that the username contains an underscore and is no more than 5 characters",
                msg);
    }

    @Test
    public void testPasswordCorrectFormat_Message() {
        String msg = login.registerUser("Kyle", "Smith", "Kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(msg.contains("Username Successfully captured."));
        assertTrue(msg.contains("Password Successfully captured."));
        assertTrue(msg.contains("Cell phone number Successfully captured."));
    }

    @Test
    public void testPasswordIncorrectFormat_Message() {
        String msg = login.registerUser("Kyle", "Smith", "Kyl_1", "password", "+27838968976");
        assertEquals("Password is not correctly formatted, please ensure that the password is at least 8 characters long, has a capital letter, a number and a special character.",
                msg);
    }

    @Test
    public void testCellNumberCorrectFormat_Message() {
        String msg = login.registerUser("Kyle", "Smith", "Kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(msg.contains("Username Successfully captured."));
        assertTrue(msg.contains("Password Successfully captured."));
        assertTrue(msg.contains("Cell phone number Successfully captured."));
    }

    @Test
    public void testCellNumberIncorrectFormat_Message() {
        String msg = login.registerUser("Kyle", "Smith", "Kyl_1", "Ch&&sec@ke99!", "08966553");
        assertEquals("Cell Number is incorrectly formatted, or does not contain an international country code,Please correct the number and try again.",
                msg);
    }

    @Test
    public void testLoginSuccessful_True() {
        login.registerUser("Kyle", "Smith", "Kyl_1", "Ch&&sec@ke99!", "+27838968976");
        boolean ok = login.loginUser("Kyl_1", "Ch&&sec@ke99!");
        assertTrue(ok);
        assertEquals("Welcome Kyle, Smith it is great to see you.", login.returnLoginStatus());
    }

    @Test
    public void testUsernameCorrectFormat_true() {
        assertTrue(login.checkUsername("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectFormat_false() {
        assertFalse(login.checkUsername("Kyle!!!!!!!"));
    }

    @Test
    public void testPasswordCorrectFormat_true() {
        assertTrue(login.checkPassword("Ch&&sec@ke99!"));  // <-- assuming method exists
    }

    @Test
    public void testPasswordIncorrectFormat_false() {
        assertFalse(login.checkPassword("password"));  // <-- assuming method exists
    }

    @Test
    public void testCellNumberCorrectFormat_true() {
        assertTrue(login.checkCellNumber("+27838968976"));  // <-- assuming method exists
    }

    @Test
    public void testCellNumberIncorrectFormat_false() {
        assertFalse(login.checkCellNumber("08966553"));  // <-- assuming method exists
    }
}
